double    cputime(void);

