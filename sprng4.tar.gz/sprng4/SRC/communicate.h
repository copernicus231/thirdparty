void get_proc_info_mpi(int *, int *);
int make_new_seed_mpi(void);
