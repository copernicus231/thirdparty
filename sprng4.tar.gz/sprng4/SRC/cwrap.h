#ifndef _CWRAP_H
#define _CWRAP_H

/************************************************************************/
/************************************************************************/
/*      Inter-language Naming Convention Problem Solution               */
/*                                                                      */
/*      Note that with different compilers you may find that            */
/*      the linker fails to find certain modules due to the naming      */
/*      conventions implicit in particular compilers.  Here the         */
/*      solution was to look at the object code produced by the FORTRAN */
/*      compiler and modify this wrapper code so that the C routines    */
/*      compiled with the same routine names as produced in the FORTRAN */
/*      program.                                                        */
/*                                                                      */
/************************************************************************/
/************************************************************************/

/*
Turn funcName from C.
*/

#define ffree_rng               cfree_rng
#define fmake_new_seed          cmake_new_seed
#define fseed_mpi               cseed_mpi
#define finit_rng               cinit_rng
#define fspawn_rng              cspawn_rng
#define fget_rn_int             cget_rn_int
#define fget_rn_flt             cget_rn_flt
#define fget_rn_dbl             cget_rn_dbl
#define fget_seed_rng           cget_seed_rng
#define fpack_rng               cpack_rng
#define funpack_rng             cunpack_rng
#define fprint_rng              cprint_rng

#define finit_rng_sim           cinit_rng_sim
#define fget_rn_int_sim         cget_rn_int_sim
#define fget_rn_flt_sim         cget_rn_flt_sim
#define fget_rn_dbl_sim         cget_rn_dbl_sim
#define finit_rng_simmpi        cinit_rng_simmpi
#define fget_rn_int_simmpi      cget_rn_int_simmpi
#define fget_rn_flt_simmpi      cget_rn_flt_simmpi
#define fget_rn_dbl_simmpi      cget_rn_dbl_simmpi
#define fpack_rng_simple        cpack_rng_simple
#define funpack_rng_simple      cunpack_rng_simple
#define fprint_rng_simple       cprint_rng_simple

#define fcpu_t                  ccpu_t

#endif
