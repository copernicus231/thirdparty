#include <cstdio>
#include <cstdlib>

using namespace std;

double myrandom_()              /* remove _ before C compilation */
{
  return (double) rand()/RAND_MAX;
}
