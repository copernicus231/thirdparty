#ifndef _cwrap_h
#define _cwrap_h

/************************************************************************/
/************************************************************************/
/*      Inter-language Naming Convention Problem Solution               */
/*                                                                      */
/*      Note that with different compilers you may find that            */
/*      the linker fails to find certain modules due to the naming      */
/*      conventions implicit in particular compilers.  Here the         */
/*      solution was to look at the object code produced by the FORTRAN */
/*      compiler and modify this wrapper code so that the C routines    */
/*      compiled with the same routine names as produced in the FORTRAN */
/*      program.                                                        */
/*                                                                      */
/************************************************************************/
/************************************************************************/

#define SPRNG_LFG   0
#define SPRNG_LCG   1
#define SPRNG_LCG64 2
#define SPRNG_CMRG  3
#define SPRNG_MLFG  4
#define SPRNG_PMLCG 5

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

int cget_seed_rng(int **genptr);
int cfree_rng(int **genptr);
int cmake_new_seed(void);
int * cinit_rng_sim(int *seed,  int *mult, int *gtype);
int * cinit_rng(int * rng_type, int *gennum, int *total_gen, int *seed, int *length);
int cspawn_rng(int **genptr,  int *nspawned, int **newGen);
int cget_rn_int_sim(void);
int cget_rn_int(int **genptr);
float cget_rn_flt_sim(void);
float cget_rn_flt(int **genptr);
double cget_rn_dbl_sim(void);
double cget_rn_dbl(int **genptr);
int cpack_rng(int **genptr, char **buffer);
int cpack_rng_simple(char **buffer);
int * cunpack_rng(char *buffer, int *rng_type);
int * cunpack_rng_simple(char *buffer, int *rng_type);
int cprint_rng( int **genptr);
int cprint_rng_simple(void);
int cseed_mpi(void);

#ifdef SPRNG_MPI

int * cinit_rng_simmpi(int *seed, int *mult, int * rng_type);
int cget_rn_int_simmpi(void);
float cget_rn_flt_simmpi(void);
double cget_rn_dbl_simmpi(void);

#endif

double ccpu_t(void);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif
